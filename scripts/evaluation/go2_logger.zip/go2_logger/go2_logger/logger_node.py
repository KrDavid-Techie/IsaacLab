import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from sensor_msgs.msg import JointState, Imu, BatteryState
from nav_msgs.msg import Odometry
from rclpy.serialization import serialize_message
import rosbag2_py
import numpy as np
import time
import csv
import os
import sys
import socket
import platform
import xml.etree.ElementTree as ET
from datetime import datetime
import threading

# Unitree SDK Imports
try:
    from unitree_sdk2py.core.channel import ChannelFactoryInitialize, ChannelSubscriber
    from unitree_sdk2py.idl.default import LowState_ as unitree_go_msg_dds__LowState_
except ImportError as e:
    print(f"Error: unitree_sdk2py not found or failed to import. {e}")
    sys.exit(1)

# Function to help detect network interface from CYCLONEDDS_URI
def get_interface_from_cyclonedds_env():
    uri = os.environ.get('CYCLONEDDS_URI')
    if not uri:
        return None
    try:
        if os.path.isfile(uri):
            tree = ET.parse(uri)
            root = tree.getroot()
        elif uri.strip().startswith('<'):
            root = ET.fromstring(uri)
        else:
            return None
        for interface in root.iter('NetworkInterface'):
            name = interface.get('name')
            if name:
                return name
    except Exception:
        return None
    return None

# Function to help detect network interface from IP
def get_network_interface(input_str):
    try:
        socket.inet_aton(input_str)
        is_ip = True
    except socket.error:
        is_ip = False
    if is_ip and platform.system() == 'Linux':
        try:
            import fcntl
            import struct
            if os.path.exists('/sys/class/net'):
                interfaces = os.listdir('/sys/class/net')
                for iface in interfaces:
                    try:
                        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                        if_ip = socket.inet_ntoa(fcntl.ioctl(
                            s.fileno(),
                            0x8915,
                            struct.pack('256s', iface[:15].encode('utf-8'))
                        )[20:24])
                        if if_ip == input_str:
                            return iface
                    except Exception:
                        continue
        except ImportError:
            pass
    return input_str

# Main Logger Node
class UnitreeLogger(Node):
    def __init__(self):
        super().__init__('unitree_logger_node')
        
        # Parameters
        self.declare_parameter('network_interface', 'enp2s0')
        
        # Set default log directory to '~/go2_logger/logs'
        default_log_dir = os.path.join(os.path.expanduser('~'), 'go2_logger', 'logs')
        self.declare_parameter('log_dir', default_log_dir)
        
        net_iface_param = self.get_parameter('network_interface').get_parameter_value().string_value
        self.log_dir = self.get_parameter('log_dir').get_parameter_value().string_value
        
        # Network Interface Detection
        if net_iface_param:
            self.network_interface = net_iface_param
        else:
            detected_iface = get_interface_from_cyclonedds_env()
            if detected_iface:
                self.network_interface = detected_iface
                self.get_logger().info(f"Auto-detected network interface: {self.network_interface}")
            else:
                self.network_interface = 'enp2s0'
                self.get_logger().warn(f"Could not detect interface. Defaulting to {self.network_interface}")

        self.get_logger().info(f"Initializing Logger on {self.network_interface}...")
        
        # Initialize SDK Channel
        net_iface = get_network_interface(self.network_interface)
        ChannelFactoryInitialize(0, net_iface)
        
        self.sub = ChannelSubscriber("rt/lowstate", unitree_go_msg_dds__LowState_)
        self.sub.Init() # Initialize Subscriber
        
        # Subscribe to cmd_vel
        self.latest_cmd_vel = Twist() # Initialize with zero values
        self.cmd_sub = self.create_subscription(Twist, 'cmd_vel', self.cmd_vel_callback, 10)
        
        # Setup CSV
        os.makedirs(self.log_dir, exist_ok=True)
        today_str = datetime.now().strftime("%Y-%m-%d")
        self.csv_path = os.path.join(self.log_dir, f"real_log_{today_str}.csv")
        
        file_exists = os.path.isfile(self.csv_path)
        self.csv_file = open(self.csv_path, 'a', newline='')
        self.writer = csv.writer(self.csv_file)
        
        # Header
        if not file_exists:
            header = ['wall_time', 'timestamp']
            header += [f'cmd_vel_{i}' for i in range(3)] # vx, vy, wz
            header += [f'base_lin_vel_{i}' for i in range(3)] # vx, vy, vz
            header += [f'base_ang_vel_{i}' for i in range(3)] # wx, wy, wz
            header += [f'base_acc_{i}' for i in range(3)] # ax, ay, az
            header += [f'base_quat_{i}' for i in range(4)] # w, x, y, z
            header += ['rpy_roll', 'rpy_pitch', 'rpy_yaw'] # Euler angles
            header += [f'dof_pos_{i}' for i in range(12)] 
            header += [f'dof_vel_{i}' for i in range(12)]
            header += [f'dof_torque_{i}' for i in range(12)]
            header += [f'motor_temp_{i}' for i in range(12)]
            header += [f'foot_force_{i}' for i in range(4)]
            header += ['bms_voltage', 'bms_current', 'bms_soc', 'power']
            header += ['error_vx', 'error_vy', 'error_wz']
            self.writer.writerow(header)
        
        # Setup MCAP Writer
        # Note: MCAP/Rosbag2 creates a directory. We create a new bag for each run to avoid appending issues.
        time_str = datetime.now().strftime("%H%M%S")
        bag_name = f"real_log_{time_str}"
        bag_path = os.path.join(self.log_dir, bag_name)
        
        self.bag_writer = rosbag2_py.SequentialWriter()
        storage_options = rosbag2_py._storage.StorageOptions(
            uri=bag_path,
            storage_id='mcap'
        )
        converter_options = rosbag2_py._storage.ConverterOptions('', '')
        self.bag_writer.open(storage_options, converter_options)
        
        # Create Topics for MCAP
        self.bag_writer.create_topic(rosbag2_py.TopicMetadata(
            name='/cmd_vel',
            type='geometry_msgs/msg/Twist',
            serialization_format='cdr'))
        self.bag_writer.create_topic(rosbag2_py.TopicMetadata(
            name='/joint_states',
            type='sensor_msgs/msg/JointState',
            serialization_format='cdr'))
        self.bag_writer.create_topic(rosbag2_py.TopicMetadata(
            name='/imu',
            type='sensor_msgs/msg/Imu',
            serialization_format='cdr'))
        self.bag_writer.create_topic(rosbag2_py.TopicMetadata(
            name='/battery_state',
            type='sensor_msgs/msg/BatteryState',
            serialization_format='cdr'))
        self.bag_writer.create_topic(rosbag2_py.TopicMetadata(
            name='/odom',
            type='nav_msgs/msg/Odometry',
            serialization_format='cdr'))

        self.running = True
        self.start_time = None
        self.log_thread = threading.Thread(target=self.log_loop)
        self.log_thread.start()
        
        self.get_logger().info(f"Logging started to {self.csv_path}")

    # Callback for cmd_vel
    # (다른 함수에 인자로 전달되어, 특정 작업이 완료된 후 호출되는 함수)
    def cmd_vel_callback(self, msg):
        self.latest_cmd_vel = msg

    def log_loop(self):
        while self.running:
            # No need to wait for cmd_vel, it is initialized to zero
            
            state = self.sub.Read()
            if state is not None:
                if self.start_time is None:
                    self.start_time = time.time()
                
                current_time = time.time() - self.start_time
                timestamp_csv = datetime.now().strftime("%H:%M:%S.%f")[:-3]
                
                # Extract Data First
                # Joint States
                q = [m.q for m in state.motor_state[:12]]
                dq = [m.dq for m in state.motor_state[:12]]
                tau = [m.tau_est for m in state.motor_state[:12]]
                motor_temp = [m.temperature for m in state.motor_state[:12]]
                
                # IMU
                wx, wy, wz = 0.0, 0.0, 0.0
                ax, ay, az = 0.0, 0.0, 0.0
                quat_w, quat_x, quat_y, quat_z = 1.0, 0.0, 0.0, 0.0
                
                if hasattr(state, 'imu_state'):
                    wx, wy, wz = state.imu_state.gyroscope
                    ax, ay, az = state.imu_state.accelerometer
                    quat_w, quat_x, quat_y, quat_z = state.imu_state.quaternion

                # Calculate RPY from Quaternion
                # Roll (x-axis rotation)
                sinr_cosp = 2 * (quat_w * quat_x + quat_y * quat_z)
                cosr_cosp = 1 - 2 * (quat_x * quat_x + quat_y * quat_y)
                roll = np.arctan2(sinr_cosp, cosr_cosp)

                # Pitch (y-axis rotation)
                sinp = 2 * (quat_w * quat_y - quat_z * quat_x)
                if abs(sinp) >= 1:
                    pitch = np.copysign(np.pi / 2, sinp)
                else:
                    pitch = np.arcsin(sinp)

                # Yaw (z-axis rotation)
                siny_cosp = 2 * (quat_w * quat_z + quat_x * quat_y)
                cosy_cosp = 1 - 2 * (quat_y * quat_y + quat_z * quat_z)
                yaw = np.arctan2(siny_cosp, cosy_cosp)

                # Base Velocity (Estimated if available, else 0)
                vx, vy, vz = 0.0, 0.0, 0.0
                if hasattr(state, 'velocity'):
                     vx, vy, vz = state.velocity

                # Foot Force
                foot_force = list(state.foot_force)

                # BMS
                bms_voltage = state.power_v
                bms_current = state.power_a
                bms_soc = state.bms_state.soc
                power = bms_voltage * bms_current

                # Write to MCAP
                timestamp_nanos = self.get_clock().now().nanoseconds
                
                # 1. Cmd Vel
                self.bag_writer.write(
                    '/cmd_vel',
                    serialize_message(self.latest_cmd_vel),
                    timestamp_nanos
                )
                
                # 2. Joint States
                js = JointState()
                js.header.stamp = self.get_clock().now().to_msg()
                js.name = [f'joint_{i}' for i in range(12)]
                js.position = [float(x) for x in q]
                js.velocity = [float(x) for x in dq]
                js.effort = [float(x) for x in tau]
                self.bag_writer.write(
                    '/joint_states',
                    serialize_message(js),
                    timestamp_nanos
                )
                
                # 3. IMU
                imu = Imu()
                imu.header.stamp = self.get_clock().now().to_msg()
                imu.angular_velocity.x = float(wx)
                imu.angular_velocity.y = float(wy)
                imu.angular_velocity.z = float(wz)
                imu.linear_acceleration.x = float(ax)
                imu.linear_acceleration.y = float(ay)
                imu.linear_acceleration.z = float(az)
                imu.orientation.w = float(quat_w)
                imu.orientation.x = float(quat_x)
                imu.orientation.y = float(quat_y)
                imu.orientation.z = float(quat_z)
                self.bag_writer.write(
                    '/imu',
                    serialize_message(imu),
                    timestamp_nanos
                )
                
                # 4. Battery State
                bat = BatteryState()
                bat.header.stamp = self.get_clock().now().to_msg()
                bat.voltage = float(bms_voltage)
                bat.current = float(bms_current)
                bat.percentage = float(bms_soc) / 100.0
                self.bag_writer.write(
                    '/battery_state',
                    serialize_message(bat),
                    timestamp_nanos
                )

                # 5. Odometry (for Base Velocity)
                odom = Odometry()
                odom.header.stamp = self.get_clock().now().to_msg()
                odom.child_frame_id = "base_link"
                odom.twist.twist.linear.x = float(vx)
                odom.twist.twist.linear.y = float(vy)
                odom.twist.twist.linear.z = float(vz)
                odom.twist.twist.angular.x = float(wx)
                odom.twist.twist.angular.y = float(wy)
                odom.twist.twist.angular.z = float(wz)
                self.bag_writer.write(
                    '/odom',
                    serialize_message(odom),
                    timestamp_nanos
                )

                # Write to CSV
                # Command Velocity
                cmd_vx = self.latest_cmd_vel.linear.x
                cmd_vy = self.latest_cmd_vel.linear.y
                cmd_wz = self.latest_cmd_vel.angular.z
                
                # Calculate Errors
                error_vx = cmd_vx - vx
                error_vy = cmd_vy - vy
                error_wz = cmd_wz - wz

                row = [timestamp_csv, current_time, cmd_vx, cmd_vy, cmd_wz, vx, vy, vz, wx, wy, wz, ax, ay, az, quat_w, quat_x, quat_y, quat_z, roll, pitch, yaw] + q + dq + tau + motor_temp + foot_force + [bms_voltage, bms_current, bms_soc, power, error_vx, error_vy, error_wz]
                self.writer.writerow(row)
                
            time.sleep(0.002) # ~500Hz sampling if possible, or match sim dt

    def destroy_node(self):
        self.running = False
        if self.log_thread.is_alive():
            self.log_thread.join()
        self.csv_file.close()
        super().destroy_node()

def main(args=None):
    rclpy.init(args=args)
    node = UnitreeLogger()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        print("Shutting down logger node...")
        pass
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()

if __name__ == '__main__':
    main()
