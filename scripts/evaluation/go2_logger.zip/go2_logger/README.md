# Go2 Logger

Unitree Go2 로봇의 Sim-to-Real 검증을 위한 ROS2 기반 데이터 로거입니다.
로봇의 상태 데이터(관절, IMU, 배터리, 발바닥 힘 등)를 고주기로 수집하여 CSV(분석용) 및 MCAP(재생용) 형식으로 동시에 저장합니다.

## 사전 요구사항 (Prerequisites)

이 패키지는 **Ubuntu 22.04** 환경에서 사용하도록 설계되었습니다.

1.  **ROS2 Humble** 설치.
2.  **Unitree SDK2 Python** (`unitree_sdk2py`) 설치.
    *   이 패키지는 Unitree SDK2를 통해 로봇의 Low State 데이터를 직접 수신합니다.
    ```bash
    cd ~
    git clone https://github.com/unitreerobotics/unitree_sdk2_python.git
    cd unitree_sdk2_python
    pip install -e .
    ```
3.  **네트워크 연결**:
    *   PC와 Go2 로봇을 이더넷 케이블로 연결합니다.
    *   로봇의 기본 IP는 보통 `192.168.123.161`입니다.
    *   PC의 IP를 같은 대역인 `192.168.123.x` (예: `192.168.123.10`)으로 설정해야 합니다.
    *   `ping 192.168.123.161` 명령어로 연결을 확인하세요.

## 설치 및 빌드 (Installation)

1.  ROS2 워크스페이스 생성 (없는 경우):
    ```bash
    mkdir -p ~/ros2_ws/src
    cd ~/ros2_ws/src
    ```

2.  패키지 복사:
    이 `go2_logger` 폴더를 워크스페이스의 `src` 폴더로 복사하거나 심볼릭 링크를 생성합니다.
    ```bash
    # 예시: IsaacLab 경로에서 복사 (경로는 실제 환경에 맞게 수정)
    cp -r ~/github/IsaacLab/scripts/evaluation/go2_logger .
    ```

3.  빌드:
    ```bash
    cd ~/ros2_ws
    colcon build --packages-select go2_logger
    ```

4.  환경 설정:
    ```bash
    source install/setup.bash
    ```

## 사용법 (Usage)

1.  **네트워크 인터페이스 확인**:
    로봇과 연결된 이더넷 인터페이스 이름(예: `eth0`, `enp3s0`, `enx...`)을 확인합니다.
    ```bash
    ip addr
    ```

2.  **로거 실행**:
    ```bash
    ros2 run go2_logger logger_node --ros-args -p network_interface:=enp3s0
    ```
    *   `network_interface` 파라미터에 실제 인터페이스 이름을 입력하세요.
    *   입력하지 않으면 `CYCLONEDDS_URI` 환경변수나 시스템 설정을 통해 자동 감지를 시도하지만, 명시하는 것이 안전합니다.

## 데이터 출력 (Output)

로그 파일은 패키지 내부의 `logs` 디렉토리에 저장됩니다.

*   **저장 경로**: `go2_logger/logs/`
*   **CSV 파일**: `real_log_YYYY-MM-DD.csv`
    *   하루 동안의 모든 로그가 하나의 파일에 누적(Append)되어 저장됩니다.
    *   Python(`pandas`)이나 Excel 등을 이용한 데이터 분석에 용이합니다.
*   **MCAP 파일**: `real_log_HHMMSS/`
    *   실행 시마다 시작 시간을 이름으로 하는 별도의 폴더와 파일이 생성됩니다.
    *   Foxglove Studio 등을 이용한 시각화 및 재생(Replay)에 사용됩니다.

## CSV 데이터 구조 (CSV Data Structure)

CSV 파일(`real_log_YYYY-MM-DD.csv`)에는 다음과 같은 필드들이 포함됩니다:

| 필드명 | 설명 | 비고 |
| :--- | :--- | :--- |
| `wall_time` | 시스템 시간 | `HH:MM:SS.mmm` 형식 |
| `timestamp` | 경과 시간 | 로깅 시작 후 경과된 시간 (초) |
| `cmd_vel_0` ~ `2` | 명령 속도 | `vx`, `vy`, `wz` |
| `base_lin_vel_0` ~ `2` | 베이스 선속도 | `vx`, `vy`, `vz` (추정값) |
| `base_ang_vel_0` ~ `2` | 베이스 각속도 | `wx`, `wy`, `wz` (IMU Gyro) |
| `base_acc_0` ~ `2` | 베이스 가속도 | `ax`, `ay`, `az` (IMU Accel) |
| `base_quat_0` ~ `3` | 베이스 자세 | `w`, `x`, `y`, `z` (Quaternion) |
| `dof_pos_0` ~ `11` | 관절 위치 | FL, FR, RL, RR 순서 (각 3개 관절) |
| `dof_vel_0` ~ `11` | 관절 속도 | |
| `dof_torque_0` ~ `11` | 관절 토크 | |
| `motor_temp_0` ~ `11` | 모터 온도 | |
| `foot_force_0` ~ `3` | 발바닥 힘 | FL, FR, RL, RR |
| `bms_voltage` | 배터리 전압 | V |
| `bms_current` | 배터리 전류 | A |
| `bms_soc` | 배터리 잔량 | % |

## 수집 데이터 항목

연구 및 Sim-to-Real 분석을 위해 다음 데이터들을 수집합니다:

*   **Command**: `cmd_vel` (선속도 X/Y, 각속도 Z)
*   **Joint State**:
    *   Position (`q`), Velocity (`dq`), Torque (`tau`)
    *   Motor Temperature (`temp`) - 열효율 분석용
*   **IMU**:
    *   Angular Velocity (`gyro`), Linear Acceleration (`accel`)
    *   Orientation (`quaternion`)
*   **Sensors**:
    *   Foot Force - 지면 반력 분석용
    *   BMS (Battery Management System) - Voltage, Current, SOC (CoT 계산용)