이 폴더를 ROS2 워크스페이스의 src 폴더로 복사하거나 심볼릭 링크를 겁니다.
빌드: colcon build --packages-select go2_logger
실행: ros2 run go2_logger logger_node